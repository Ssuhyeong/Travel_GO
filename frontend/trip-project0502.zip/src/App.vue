<template>
  <div id="app">
    <myNav />
    <mainView />
    <myFooter />
  </div>
</template>

<script>
import mainView from "./views/mainView.vue";
import myNav from "./components/includes/myNav.vue";
import myFooter from "./components/includes/myFooter.vue";

export default {
  name: "App",
  components: {
    myNav,
    mainView,
    myFooter,
  },
};
</script>

<style>
@font-face {
  font-family: "CookieRun_Regular";
  src: url("../src/assets/fonts/CookieRun\ Regular.ttf");
}

@font-face {
  font-family: "CookieRun_Bold";
  src: url("../src/assets/fonts/CookieRun\ Regular.ttf");
}

@font-face {
  font-family: "CookieRun_Black";
  src: url("../src/assets/fonts/CookieRun\ Regular.ttf");
}

body {
  margin: 0px;
  padding: 0px;
  overflow-x: hidden;
}

#app {
  font-family: "CookieRun_Regular";
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  /* text-align: center; */
  color: #2c3e50;
}
</style>
